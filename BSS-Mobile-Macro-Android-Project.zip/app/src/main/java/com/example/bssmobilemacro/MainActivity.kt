package com.example.bssmobilemacro

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }

        fun addText(value: String, size: Float = 16f) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = size
                setPadding(0, 10, 0, 10)
            })
        }

        fun addButton(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        addText("BSS Mobile Macro", 25f)
        addText("Prototype v0.1")
        addText("This first build checks that the app installs and that Android grants its accessibility permission.")
        addText("No farming pattern or automatic gameplay is active in this prototype.")
        addButton("Open Accessibility Settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("Refresh permission status") {
            recreate()
        }
        val enabled = MacroAccessibilityService.isEnabled(this)
        addText(if (enabled) "Accessibility service: ENABLED" else "Accessibility service: NOT ENABLED")
        addText("Next: add and test the single-field Kettle movement pattern.")
        setContentView(layout)
    }
}
